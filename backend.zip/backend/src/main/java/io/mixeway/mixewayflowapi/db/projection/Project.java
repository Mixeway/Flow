package io.mixeway.mixewayflowapi.db.projection;


import lombok.Data;

@Data
public class Project {
    private String name;
    private String href;

    // Constructors, getters, and setters
    // ...
}