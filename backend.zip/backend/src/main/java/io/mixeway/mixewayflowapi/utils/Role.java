package io.mixeway.mixewayflowapi.utils;

public enum Role {
    ADMIN,
    USER,
    TEAM_MANAGER
}
