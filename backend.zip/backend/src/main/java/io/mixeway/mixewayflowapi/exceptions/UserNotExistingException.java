package io.mixeway.mixewayflowapi.exceptions;

public class UserNotExistingException
        extends RuntimeException {

}