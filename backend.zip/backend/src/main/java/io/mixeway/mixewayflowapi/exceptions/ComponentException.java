package io.mixeway.mixewayflowapi.exceptions;

public class ComponentException
        extends RuntimeException {
    public ComponentException(String errorMessage) {
        super(errorMessage);
    }

}