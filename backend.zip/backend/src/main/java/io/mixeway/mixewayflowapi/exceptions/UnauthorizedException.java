package io.mixeway.mixewayflowapi.exceptions;

public class UnauthorizedException
        extends RuntimeException {

}