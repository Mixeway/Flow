package io.mixeway.mixewayflowapi.integrations.repo.dto;

import lombok.Data;

@Data
public class CommentMessage {
    String body;
}
