package io.mixeway.mixewayflowapi.exceptions;

public class ScanException
        extends Exception {
    public ScanException(String errorMessage) {
        super(errorMessage);
    }

}