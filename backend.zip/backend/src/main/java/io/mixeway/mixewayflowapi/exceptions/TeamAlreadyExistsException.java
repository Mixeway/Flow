package io.mixeway.mixewayflowapi.exceptions;

public class TeamAlreadyExistsException
        extends RuntimeException {

}