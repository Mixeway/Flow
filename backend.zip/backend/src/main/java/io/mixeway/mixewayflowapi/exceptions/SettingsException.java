package io.mixeway.mixewayflowapi.exceptions;

public class SettingsException
        extends Exception {
    public SettingsException(String errorMessage) {
        super(errorMessage);
    }

}