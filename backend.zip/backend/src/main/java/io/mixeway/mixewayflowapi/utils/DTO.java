package io.mixeway.mixewayflowapi.utils;

public interface DTO {
}
